YouTube link for video: https://www.youtube.com/watch?v=FajGRIKV53g
