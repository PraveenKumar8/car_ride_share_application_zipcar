**Team Name: DBMSEmpire**

## Basic Information

|   Info      |        Description     |
| ----------- | ---------------------- |
| TeamID      |         Team-024       |
| TeamName    |        DBMSEmpire      |
| Captain     |   Praveen Murugaiah    |
| Captain     |     Captain-pkm4       |
| Member1     |   Sreekar Bathula      |
| Member1     |      Member1-bathula2  |
| Member2     |   Vivek Bhatt          |
| Member2     |      Member2-vivekb2   |
| Member3     |   Michael Trzupek      |
| Member3     |      Member3-michalt2  |


***Project Title: CarShare***

# Project Summary

CarShare is a car renting/leasing web application that allows users to rent/lease a vehicle. The main purpose is to make it hassle-free for lessors who want to rent their car for a short period of time when the car is not in use. Typically, the duration of the period would be in weeks to months. Our proposed application also makes it easier for the lessee to lend cars according to their car availability and closest CarShare station. 
CarShare takes a lot of constraints into account such as user location, valid insurance, valid license and valid age of lessee ( 21+). Furthermore, the application also mentions the car make, model, type and capacity, availability, and location.


